import React from 'react';

const Fail = () => {
  return (
    <>
      <h2> 틀렸어요ㅠㅠㅠ 다시해보세요.</h2>
    </>
  );
};

export default Fail;
